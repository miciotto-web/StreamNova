package com.example.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.MediaItem
import com.example.data.model.MediaType
import com.example.data.repository.MediaRepository
import com.example.ui.components.ContinueWatchingCard
import com.example.ui.components.HeroBanner
import com.example.ui.components.PosterMediaCard
import com.example.ui.components.StandardMediaCard
import com.example.ui.theme.NovaBackground
import com.example.ui.theme.NovaCyan
import com.example.ui.theme.NovaCyanBright
import com.example.ui.theme.NovaTextMuted
import com.example.ui.theme.NovaTextPrimary
import com.example.ui.theme.NovaTextSecondary
import com.example.ui.viewmodel.SidebarSection
import com.example.ui.viewmodel.StreamNovaViewModel
import androidx.compose.foundation.shape.RoundedCornerShape

@Composable
fun HomeScreen(
  viewModel: StreamNovaViewModel,
  modifier: Modifier = Modifier
) {
  val currentSection by viewModel.currentSection.collectAsState()
  val allMedia by viewModel.allMedia.collectAsState()

  when (currentSection) {
    SidebarSection.HOME -> {
      HomeMainBrowsingContent(
        allMedia = allMedia,
        onMediaClick = { viewModel.openDetail(it) },
        onPlayClick = { viewModel.openPlayer(it) },
        modifier = modifier
      )
    }
    SidebarSection.FILM -> {
      CategoryBrowsingScreen(
        title = "Tutti i Film in 4K HDR",
        subtitle = "I migliori lungometraggi cinematografici disponibili per te",
        items = allMedia.filter { it.type == MediaType.FILM },
        onMediaClick = { viewModel.openDetail(it) },
        modifier = modifier
      )
    }
    SidebarSection.SERIE_TV -> {
      CategoryBrowsingScreen(
        title = "Serie TV & Stagioni Complete",
        subtitle = "Produzioni pluripremiate con audio immersivo Dolby Atmos",
        items = allMedia.filter { it.type == MediaType.SERIE_TV },
        onMediaClick = { viewModel.openDetail(it) },
        modifier = modifier
      )
    }
    SidebarSection.I_MIEI_CONTENUTI -> {
      MyContentScreen(
        allMedia = allMedia,
        onMediaClick = { viewModel.openDetail(it) },
        modifier = modifier
      )
    }
    SidebarSection.CERCA -> {
      SearchScreen(
        viewModel = viewModel,
        onMediaClick = { viewModel.openDetail(it) },
        modifier = modifier
      )
    }
    SidebarSection.IMPOSTAZIONI -> {
      SettingsScreen(
        modifier = modifier
      )
    }
  }
}

enum class SortOption(val label: String) {
  POPOLARI("Popolari"),
  DATA("Data"),
  VALUTAZIONE("Valutazione")
}

@Composable
fun HomeMainBrowsingContent(
  allMedia: List<MediaItem>,
  onMediaClick: (MediaItem) -> Unit,
  onPlayClick: (MediaItem) -> Unit,
  modifier: Modifier = Modifier
) {
  val continueWatching = allMedia.filter { it.currentProgressMs > 0 }
  val featuredHero = allMedia.firstOrNull { it.id == "dune_2" } ?: allMedia.first()

  val popularItems = allMedia.sortedByDescending { it.rating }
  val popularMovies = allMedia.filter { it.type == MediaType.FILM }
  val popularSeries = allMedia.filter { it.type == MediaType.SERIE_TV }

  LazyColumn(
    modifier = modifier
      .fillMaxSize()
      .background(NovaBackground),
    contentPadding = PaddingValues(bottom = 48.dp)
  ) {
    // 1. Hero / Banner Principale
    item(key = "hero_banner") {
      HeroBanner(
        media = featuredHero,
        onPlayClick = { onPlayClick(featuredHero) },
        onInfoClick = { onMediaClick(featuredHero) }
      )
      Spacer(modifier = Modifier.height(16.dp))
    }

    // 2. Carosello: "Continua a guardare"
    if (continueWatching.isNotEmpty()) {
      item(key = "section_continue_watching") {
        CarouselSection(
          title = "Continua a guardare",
          badge = "${continueWatching.size} titoli in corso",
          items = continueWatching,
          onMediaClick = { onMediaClick(it) }
        )
      }
    }

    // 3. Carosello: "Locandine Cinema & Serie TV"
    item(key = "section_tmdb_posters") {
      CarouselSection(
        title = "Locandine Ufficiali Cinema & Serie",
        badge = "Poster TMDB",
        items = popularItems,
        onMediaClick = { onMediaClick(it) },
        cardType = CardType.POSTER
      )
    }

    // 4. Carosello: "I più popolari"
    item(key = "section_popular") {
      CarouselSection(
        title = "I più popolari su StreamNova",
        badge = "Top Votati",
        items = popularItems,
        onMediaClick = { onMediaClick(it) }
      )
    }

    // 5. Carosello: "Film popolari"
    item(key = "section_movies") {
      CarouselSection(
        title = "Film popolari in 4K HDR",
        badge = "Cinema a casa",
        items = popularMovies,
        onMediaClick = { onMediaClick(it) }
      )
    }

    // 6. Carosello: "Serie TV popolari"
    item(key = "section_series") {
      CarouselSection(
        title = "Serie TV più amate",
        badge = "Nuovi episodi",
        items = popularSeries,
        onMediaClick = { onMediaClick(it) }
      )
    }
  }
}

enum class CardType { STANDARD, POSTER }

@Composable
fun CarouselSection(
  title: String,
  badge: String?,
  items: List<MediaItem>,
  onMediaClick: (MediaItem) -> Unit,
  cardType: CardType = CardType.STANDARD
) {
  var sortOption by remember { mutableStateOf(SortOption.POPOLARI) }

  val sortedItems = remember(items, sortOption) {
    when (sortOption) {
      SortOption.POPOLARI -> items.sortedByDescending { it.rating }
      SortOption.DATA -> items.sortedByDescending { it.releaseDate ?: 0 }
      SortOption.VALUTAZIONE -> items.sortedByDescending { it.rating }
    }
  }

  val listState = rememberLazyListState()
  var contentWidth by remember { mutableIntStateOf(0) }
  var itemWidth by remember { mutableIntStateOf(236) }

  Column {
    // Header with sorting chips
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(start = 32.dp, end = 32.dp, top = 8.dp, bottom = 4.dp),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.SpaceBetween
    ) {
      Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(10.dp)
      ) {
        Text(
          text = title,
          color = NovaTextPrimary,
          fontSize = 18.sp,
          fontWeight = FontWeight.Bold,
          letterSpacing = 0.3.sp
        )
        if (badge != null) {
          Text(
            text = "• $badge",
            color = NovaCyanBright,
            fontSize = 12.sp,
            fontWeight = FontWeight.SemiBold
          )
        }
      }

      // Sorting chips
      Row(
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalAlignment = Alignment.CenterVertically
      ) {
        SortOption.values().forEach { option ->
          androidx.compose.material3.FilterChip(
            selected = sortOption == option,
            onClick = { sortOption = option },
            label = {
              Text(
                text = option.label,
                fontSize = 11.sp,
                fontWeight = if (sortOption == option) FontWeight.Bold else FontWeight.Normal
              )
            },
            colors = androidx.compose.material3.FilterChipDefaults.filterChipColors(
              selectedContainerColor = NovaCyan,
              selectedLabelColor = Color.Black,
              labelColor = NovaTextSecondary,
              selectedBorderColor = NovaCyanBright
            ),
            border = androidx.compose.material3.FilterChipDefaults.filterChipBorder(
              enabled = true,
              selected = sortOption == option,
              borderColor = if (sortOption == option) NovaCyanBright else Color(0x33FFFFFF)
            ),
            modifier = Modifier
              .clip(RoundedCornerShape(16.dp))
          )
        }
      }
    }

    // Carousel with progress indicator
    Box(
      modifier = Modifier
        .fillMaxWidth()
        .onSizeChanged { contentWidth = it.width }
    ) {
      LazyRow(
        state = listState,
        contentPadding = PaddingValues(horizontal = 32.dp, vertical = 8.dp),
        horizontalArrangement = Arrangement.spacedBy(16.dp)
      ) {
        items(sortedItems, key = { it.id }) { item ->
          if (cardType == CardType.POSTER) {
            PosterMediaCard(
              media = item,
              onClick = { onMediaClick(item) }
            )
          } else {
            StandardMediaCard(
              media = item,
              onClick = { onMediaClick(item) }
            )
          }
        }
      }

      // Carousel progress indicator
      if (contentWidth > 0) {
        CarouselProgressIndicator(
          listState = listState,
          contentWidth = contentWidth,
          itemWidth = itemWidth,
          visibleItems = sortedItems.size
        )
      }
    }

    Spacer(modifier = Modifier.height(16.dp))
  }
}

@Composable
fun CarouselProgressIndicator(
  listState: androidx.compose.foundation.lazy.LazyListState,
  contentWidth: Int,
  itemWidth: Int,
  visibleItems: Int
) {
  val layoutInfo = listState.layoutInfo
  val totalVisibleItems = layoutInfo.visibleItemsInfo.size

  if (totalVisibleItems > 0 && contentWidth > 0) {
    // Calculate scroll percentage
    val firstVisibleIndex = layoutInfo.visibleItemsInfo.firstOrNull()?.index ?: 0
    val scrollPercentage = (firstVisibleIndex.toFloat() / (visibleItems - totalVisibleItems).coerceAtLeast(1))
      .coerceIn(0f, 1f)

    Box(
      modifier = Modifier
        .align(Alignment.BottomEnd)
        .padding(16.dp)
    ) {
      Row(
        horizontalArrangement = Arrangement.spacedBy(4.dp)
      ) {
        repeat(visibleItems.coerceAtMost(10)) { index ->
          val isActive = index == firstVisibleIndex || (index in firstVisibleIndex until firstVisibleIndex + totalVisibleItems)
          Box(
            modifier = Modifier
              .width(if (isActive) 8.dp else 4.dp)
              .height(4.dp)
              .clip(RoundedCornerShape(2.dp))
              .background(if (isActive) NovaCyanBright else Color(0x33FFFFFF))
          )
        }
      }
    }
  }
}

@Composable
fun CarouselHeader(
  title: String,
  badge: String? = null,
  modifier: Modifier = Modifier
) {
  Row(
    modifier = modifier
      .fillMaxWidth()
      .padding(start = 32.dp, end = 32.dp, top = 8.dp, bottom = 4.dp),
    verticalAlignment = Alignment.CenterVertically,
    horizontalArrangement = Arrangement.SpaceBetween
  ) {
    Row(
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
      Text(
        text = title,
        color = NovaTextPrimary,
        fontSize = 18.sp,
        fontWeight = FontWeight.Bold,
        letterSpacing = 0.3.sp
      )
      if (badge != null) {
        Text(
          text = "• $badge",
          color = NovaCyanBright,
          fontSize = 12.sp,
          fontWeight = FontWeight.SemiBold
        )
      }
    }
  }
}
